KHUSHI AI PROJECT (WINDOWS + ANDROID)

WINDOWS:
1. Install Python 3.10
2. Open WINDOWS folder
3. Double-click install.bat
4. Double-click run.bat

ANDROID:
1. Install Flutter + Android Studio
2. Open ANDROID folder
3. Double-click build_apk.bat
4. Install generated APK
